# EcommerceWebisteLiquorStore
Online Liquor Store: with pick up and delivery facility designed by a group of 2nd year engineering students

Target audience :

Suppliers:
Regiter to the website, log in all funcitonalities
Functions he/she can perform:
     He can add/remove brands to his stock.

     He can change the price of his stock.
     He can add/remove products or alter the quantity of his stock.
     He can check the availability of his stock
     He can do edit/update in “area of serving” attribute.


Customers:
Regiter to the website, log in all funcitonalities
Functions he/she can perform:
      He can search for his/her specific brand&#39;s availability.

       He can check nearby shops from where he can get his brand.
       He can place an order.
       He can view item availability status.
      
      
      #Tags:-
      Python , Flask, SqlAlchemy,DBMS,SQL
